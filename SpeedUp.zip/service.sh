#!/system/bin/sh
# Wait for the system to fully boot
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

# Wait for the user to unlock the device (removes lag from the lockscreen)
while [ "$(getprop sys.user_unlocked)" != "true" ]; do
  sleep 2
done

# Wait 30 seconds after unlock to let the UI settle
sleep 30

# 1. Trim caches to free up eMMC bandwidth (Your requested command)
pm trim-caches 999G

# 2. Boost priority for the UI and System Server
# -20 is the highest priority in Linux
renice -n -20 -p $(pidof surfaceflinger)
renice -n -20 -p $(pidof system_server)

# 3. Disable debugging/logging that slows down mid-range chips
setprop debug.atrace.tags.enableflags 0
resetprop -n dalvik.vm.dex2oat-cpu-set 0,1

# 4. Stop the Google "Chimera" service from hogging RAM immediately
am force-stop com.google.android.gms/.chimera.GmsIntentOperationService

exit 0
