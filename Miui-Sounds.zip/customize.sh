# Set what you want to display when installing your module

print_modname() {
  ui_print "*****************************************"
  ui_print "           MIUI SOUNDS    "
  ui_print "   Extracted and Packed by 𝚅𝙾𝙽 𝙱𝙰𝙸𝙻𝙴𝚈   "
  ui_print "******************************************"
}
