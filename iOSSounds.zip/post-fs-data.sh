#!/system/bin/sh
# This script ensures the system recognizes new media files
MODDIR=${0%/*}

# Set correct permissions for the audio folders
chmod -R 755 $MODDIR/system/product/media/audio
